module Vehicle_disp
	def vehicle_display(no_of_wheels,colour,price,brand)
		puts "#{no_of_wheels}	#{colour}	#{price}	#{brand}"
		
	end
end